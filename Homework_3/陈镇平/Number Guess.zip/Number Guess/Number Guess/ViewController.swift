//
//  ViewController.swift
//  Number Guess
//
//  Created by Calm on 2019/9/25.
//  Copyright © 2019 Calm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var minimumTextField: UITextField!
    @IBOutlet weak var maximumTextField: UITextField!
    @IBOutlet weak var randomNumLabel: UILabel!
    @IBOutlet weak var minimumLabel: UILabel!
    @IBOutlet weak var maximumLabel: UILabel!
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var hitMessage: UIStackView!
    @IBOutlet weak var guessNumStackVeiw: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func generateRandomNum(_ sender: UIButton) {
        let min=Int(minimumTextField.text!)
        let max=Int(maximumTextField.text!)
        let num=Int(arc4random())%(max!-min!-1)+min!+1
        randomNumLabel.text=String(num)
        minimumLabel.text=String(min!)
        maximumLabel.text=String(max!)
        guessNumStackVeiw.isHidden=false
    }
    
    @IBAction func guess(_ sender: UIButton) {
        let num=Int(randomNumLabel.text!)!
        let testNum=Int(inputTextField.text!)!
        if num==testNum{
            hitMessage.isHidden=false
        }
        else if testNum<num{
            minimumLabel.text=String(testNum)
            inputTextField.text=""
        }
        else if testNum>num {
            maximumLabel.text=String(testNum)
            inputTextField.text=""
        }
    }
    @IBAction func newGame(_ sender: UIButton) {
        guessNumStackVeiw.isHidden=true
        hitMessage.isHidden=true
        minimumTextField.text=String(0)
        maximumTextField.text=String(100)
    }
}

