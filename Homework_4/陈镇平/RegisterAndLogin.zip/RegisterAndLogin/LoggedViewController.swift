//
//  LoggedViewController.swift
//  RegisterAndLogin
//
//  Created by Calm on 2019/11/24.
//  Copyright © 2019 Calm. All rights reserved.
//

import UIKit

class LoggedViewController: UIViewController {
    @IBOutlet weak var idLabel: UILabel!
    var user :User?
    override func viewDidLoad() {
        super.viewDidLoad()
        idLabel.text=user!.id
        // Do any additional setup after loading the view.
    }
    @IBAction func logout(_ sender: UIButton) {
        performSegue(withIdentifier: "unwindFromLogged", sender: self)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
