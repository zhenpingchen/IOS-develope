//
//  ViewController.swift
//  RegisterAndLogin
//
//  Created by Calm on 2019/11/22.
//  Copyright © 2019 Calm. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    var users=[User]()  //已注册用户
    var loggedUser:User?
    
    @IBOutlet weak var loginId: UITextField!
    @IBOutlet weak var loginPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let registered=lodeUsers() {
        users+=registered
        }
    }
    @IBAction func login(_ sender: UIButton) {
        let id=loginId.text!
        let user=getUser(id: id)
        let password=loginPassword.text
        if user != nil && user?.password==password{
            loggedUser=user
            self.performSegue(withIdentifier: "login", sender: self)
        }
        else{   //错误提示
            let alertToast = UIAlertController(title: "登陆异常", message: "用户名或密码错误", preferredStyle: .alert)
            
            present(alertToast, animated: true, completion: nil)
            
            //一秒钟后自动消失
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                
                alertToast.dismiss(animated: false, completion: nil)
                
            }
            
        }
        
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch(segue.identifier ?? "") {
        case "login":
            let destVc:LoggedViewController = segue.destination as! LoggedViewController
            destVc.user = loggedUser!
            break
        case "register":
            let destVc=segue.destination as! RegisterViewController
            destVc.users=self.users
            break
        default:
            break
        }
    }
    
    @IBAction func unwindfromRegister(sender:UIStoryboardSegue){
        if let svc=sender.source as? RegisterViewController{
            users=svc.users
        }
    }
    @IBAction func unwindfromLogged(sender:UIStoryboardSegue){
    }
    private func getUser(id:String)->User?{
        for user in users{
            if user.id==id{
                return user
            }
        }
        return nil
    }
    private func lodeUsers()->[User]?{
       return NSKeyedUnarchiver.unarchiveObject(withFile: User.ArchiveURL.path) as? [User]
    }
}

