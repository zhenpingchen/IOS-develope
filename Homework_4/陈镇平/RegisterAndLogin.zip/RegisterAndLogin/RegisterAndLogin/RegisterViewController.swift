//
//  RegisterViewController.swift
//  RegisterAndLogin
//
//  Created by Calm on 2019/11/25.
//  Copyright © 2019 Calm. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {
    var users:[User] = []
    
    
    @IBOutlet weak var inputId: UITextField!
    @IBOutlet weak var inputPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        inputId.text=""
        inputPassword.text=""
        // Do any additional setup after loading the view.
    }
    private func getUser(id:String)->User?{
        for user in users{
            if user.id==id{
                return user
            }
        }
        return nil
    }

    @IBAction func register(_ sender: UIButton) {
        guard let id=inputId.text,let password=inputPassword.text else{
            let alert = UIAlertController(title: "用户名或密码不能为空", message: "", preferredStyle: .alert)
            let action=UIAlertAction(title:"我知道了",style: .default,handler:nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
       return
        }
        var user=getUser(id:id)
        if user != nil{
            let alert = UIAlertController(title: "账号被占用", message: "", preferredStyle: .alert)
            let action=UIAlertAction(title:"我知道了",style: .default,handler:nil)
            let action_1 = UIAlertAction(title: "去登陆", style: .default, handler: {(any: UIAlertAction)-> Void in
                self.performSegue(withIdentifier: "unwindfromRegister", sender: self)                })
            alert.addAction(action_1)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
        }
        else{
            user=User(id:id,password: password)
            users.append(user!)
            saveUsers()
            let alert = UIAlertController(title: "提示", message: "注册成功", preferredStyle: .alert)
            let action = UIAlertAction(title: "去登陆", style: .default, handler: {(any: UIAlertAction)-> Void in
                    self.performSegue(withIdentifier: "unwindfromRegister", sender: self)                })
            alert.addAction(action)
            present(alert,animated: true,completion: nil)
        }
    }
    private func saveUsers(){
        NSKeyedArchiver.archiveRootObject(users, toFile: User.ArchiveURL.path)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
