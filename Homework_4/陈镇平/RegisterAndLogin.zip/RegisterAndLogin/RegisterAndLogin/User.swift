//
//  File.swift
//  RegisterAndLogin
//
//  Created by Calm on 2019/11/23.
//  Copyright © 2019 Calm. All rights reserved.
//

import UIKit

class User:NSObject,NSCoding{
    var id:String
    var password:String
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("users")
    
    init?(id:String ,password:String){
        guard !id.isEmpty && !password.isEmpty else{
            return nil
        }
        self.id=id
        self.password=password
    }
    
    func encode(with aCoder:NSCoder){
        aCoder.encode(id, forKey:"id")
        aCoder.encode(password, forKey:"password")
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        guard let id=aDecoder.decodeObject(forKey:"id") as? String else{
            return nil
        }
        guard let password=aDecoder.decodeObject(forKey:"password") as? String else{
            return nil
        }
        self.init(id:id,password:password)
    }
}
